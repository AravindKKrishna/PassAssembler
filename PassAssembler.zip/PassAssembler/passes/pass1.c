#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
int l,loc,start;
char label[10],opcode[10],operand[10],code[10],value[10];
FILE *fp1,*fp2,*fp3,*fp4;
fp1=fopen("input.txt","r");
fp2=fopen("optab.txt","r");
fp3=fopen("symtab.txt","w");
fp4=fopen("output.txt","w");
fscanf(fp1,"%s\t%s\t%s",label,opcode,operand);
if(strcmp(opcode,"start")==0)
{
start=atoi(operand);
loc=start;
fprintf(fp4,"\t%s\t%s\t%s\n",label,opcode,operand);
fscanf(fp1,"%s\t%s\t%s",label,opcode,operand);
}
else
{
loc=0;
}
while(strcmp(opcode,"end")!=0)
{
fprintf(fp4,"%d\t",loc);
if(strcmp(label,"**")!=0)
fprintf(fp3,"%s\t%d\n",label,loc);
fscanf(fp2,"%s\t%s",code,value);
while(strcmp(code,"end")!=0)
{
if(strcmp(code,opcode)==0)
{
loc+=3;
break;
}
fscanf(fp2,"%s\t%s",code,value);
}
if(strcmp(opcode,"word")==0)
loc+=3;
else if(strcmp(opcode,"resw")==0)
loc+=(3*(atoi(operand)));
else if(strcmp(opcode,"resb")==0)
loc+=atoi(operand);
else if(strcmp(opcode,"byte")==0)
loc+=(strlen(operand)-3);
 
fprintf(fp4,"%s\t%s\t%s\n",label,opcode,operand);
fscanf(fp1,"%s\t%s\t%s",label,opcode,operand);

}
fprintf(fp4,"%d\t%s\t%s\t%s\n",loc,label,opcode,operand);
l=loc-start;
printf("Length of the code = %d\t",l);
fclose(fp1);
fclose(fp2);
fclose(fp3);
fclose(fp4);
}






